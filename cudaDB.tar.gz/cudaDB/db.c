#include <stdio.h>
#include <sqlite3.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <math.h>
#pragma GCC diagnostic ignored "-Wunused-parameter"

static int callback(void *NotUsed, int argc, char **argv, char **azColName){
	int i;
	for(i=0; i<argc; i++){
		printf("%s = %s\t", azColName[i], argv[i] ? argv[i] : "NULL");
	}
	printf("\n");
	return 0;
}



void create_tables(sqlite3 *db) {
	int r;
	char *err = 0;

	r = sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS test (rowNo INTEGER PRIMARY KEY, column1 INTEGER, column2 INTEGER, column3 INTEGER, columnf4 FLOAT, columnf5 FLOAT, columnf6 FLOAT)",
		callback, 0, &err);

	if(r != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err);
		sqlite3_free(err);
	}
}

void insert_data(sqlite3 *db, int rows) {
	char* err = 0;
	int i;
	int r;

	r = sqlite3_exec(db, "PRAGMA synchronous = 0", NULL, 0, &err);

	if(r != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err);
		sqlite3_free(err);
	}

	fprintf(stderr, "executed pragma\n");

	r = sqlite3_exec(db, "BEGIN TRANSACTION", NULL, 0, &err);

	if(r != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err);
		sqlite3_free(err);
	}

	fprintf(stderr, "started transaction\n");

	sqlite3_stmt *stmt;
	sqlite3_prepare_v2(db,
		"INSERT INTO test (rowNo, column1, column2, column3, columnf4, columnf5, columnf6) VALUES (?,?,?,?,?,?,?)", 
		512,
		&stmt,
		0);
    srand( (unsigned)time( NULL ) );
	for(i = 0; i < rows; i++) {
		sqlite3_bind_int(stmt, 1, i);
		sqlite3_bind_int(stmt, 2,rand()%100);
		sqlite3_bind_int(stmt, 3, rand()%5);
		sqlite3_bind_int(stmt, 4, rand()%20);
		sqlite3_bind_double(stmt, 5, (float)rand()/((float)RAND_MAX/100));
		sqlite3_bind_double(stmt, 6, (float)rand()/((float)RAND_MAX/5.0));
		sqlite3_bind_double(stmt, 7, (float)rand()/((float)RAND_MAX/20));
		int r = sqlite3_step(stmt);

		if(r != SQLITE_DONE && r != SQLITE_OK) {
			fprintf(stderr, "SQL error: %s\n", sqlite3_errmsg(db));
			sqlite3_free(err);
			return;
		}

		sqlite3_reset(stmt);
		
		if(i % 10000 == 0)
			printf("%i\n", i);
	}

	sqlite3_finalize(stmt);

	sqlite3_exec(db, "COMMIT", 0, 0, &err);

	if(r != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err);
		sqlite3_free(err);
	}
}


void time_execution(sqlite3 *db, const char* cmd)
{
	printf("Starting execution of command\n%s\n", cmd);

	char* err;

	struct timeval t;
	gettimeofday(&t, NULL);
	double starttime = (double)t.tv_sec + (double)t.tv_usec / 1000000;

	int r = sqlite3_exec(db, cmd, &callback, NULL, &err);

	if(r != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", err);
		sqlite3_free(err);
	}

	gettimeofday(&t, NULL);
	double endtime = (double)t.tv_sec + (double)t.tv_usec / 1000000;

	printf("================\n");
	printf(" %e seconds\n", endtime - starttime);
	printf("================\n");
}



int main(int argc, char **argv){
	sqlite3 *db;
	char *zErrMsg = 0;
	int rc;

	if(argc != 3) {
		fprintf(stderr, "%s <database name> <rows>\n", argv[0]);
		exit(1);
	}

  
        rc = sqlite3_open(argv[1], &db);
	
        if( rc ){
		fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
		sqlite3_close(db);
		exit(1);
	}

	create_tables(db);

	fprintf(stderr, "tables created\n");

	insert_data(db, atoi(argv[2]));
	
	rc = sqlite3_exec(db, "SELECT * FROM test", callback, 0, &zErrMsg);

	if(rc != SQLITE_OK) {
		fprintf(stderr, "SQL error: %s\n", zErrMsg);
		sqlite3_free(zErrMsg);
	}


	sqlite3_close(db);

	return 0;
}
