#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

#include "sqlite3.h"
#include "sqliteInt.h"
#include "vdbe.h"
#include "vdbeInt.h"
#include "opcodes.h"

#include "cuda_runtime_api.h"
#include "driver_types.h"
#include "cuda_runtime.h" 


#define Cd_SUCCESS		0
#define Cd_ERR_MEM		1
#define Cd_ERR_STMT		2
#define Cd_ERR_CUDAMEMCPY	3
#define Cd_ERR_CUDAMALLOC	4
#define Cd_ERR_DEVICE		5
#define Cd_ERR_CUDAFREE	6
#define Cd_ERR_CUDAFREEHOST	7
#define Cd_ERR_KERNEL		8
#define Cd_ERR_TYPE		9
#define Cd_ERR_TEXTURE		10

#define Cd_AGG_COUNT		0
#define Cd_AGG_MIN		1
#define Cd_AGG_MAX		2
#define Cd_AGG_SUM		3
#define Cd_AGG_AVG		4

#define Cd_AGG_STR_COUNT	"count"
#define Cd_AGG_STR_MIN		"min"
#define Cd_AGG_STR_MAX		"max"
#define Cd_AGG_STR_SUM		"sum"
#define Cd_AGG_STR_AVG		"avg"

#define Cd_MAX_OPS		64
#define Cd_MAX_COLUMNS		16
#define Cd_REGISTERS		32
#define Cd_GLOBAL_REGISTERS	8
#define Cd_THREADSPERBLOCK	256
#define Cd_STREAMWIDTH		2

#define Cd_INT			0
#define Cd_INT64			1
#define Cd_FLOAT			2
#define Cd_DOUBLE		3
#define Cd_ULLI			4
#define Cd_NULL			5

#define Cd_KB			1024
#define Cd_MB			1048576
#define Cd_GB			1073741824




struct Cd_op {
	u8 opcode;
	int p1;
	int p2;
	int p3;
	union {
		int i;
		i64 li;
		float f;
		double d;
	} p4;
	u8 p5;
} __attribute__((aligned (32))); 

typedef struct Cd_op Cd_op;

struct Cd_stmt {
	int start;	
	int nOp;
	Cd_op op[Cd_MAX_OPS];
};
typedef struct Cd_stmt Cd_stmt;

#define Cd_DATA_PADDING (128 - (((3 + 2 * Cd_MAX_COLUMNS) * sizeof(int)) % 128))
struct Cd_data {
	int rows;
	int columns;
	int stride;
	int types[Cd_MAX_COLUMNS];
	int offsets[Cd_MAX_COLUMNS];

	char d[];
};
typedef struct Cd_data Cd_data;


struct Cd_data_gpu {
	int rows;
	int columns;
	int stride;
	int types[Cd_MAX_COLUMNS];
	int offsets[Cd_MAX_COLUMNS];
};
typedef struct Cd_data_gpu Cd_data_gpu;


struct Cd_results {
	int rows;
	int columns;
	int stride;
	int types[Cd_MAX_COLUMNS];
	int offsets[Cd_MAX_COLUMNS];
	char r[];
};
typedef struct Cd_results Cd_results;


struct Cd_mem {
	union {
		int i;
		i64 li;
		unsigned long long int ulli;
		float f;
		double d;
		struct {
			int hi;
			int lo;
		} segment;
	} mem;
	int type;
};typedef struct Cd_mem Cd_mem;


struct Cd {
	sqlite3 *db;				// pointer to sqlite 3 database
	Cd_data *data_cpu;		// pointer to data block on cpu
	char *data_gpu;				// pointer to data block on gpu
	Cd_results *results_cpu;	// pointer to results block on cpu
	Cd_results *results_gpu;	// pointer to results block on gpu
	Cd_stmt *stmt_cpu;		// pointer to instruction block on cpu
	size_t data_size;				// size of data block
	size_t results_size;			// size of results block
	int threads_per_block;			// set to max
	int pinned_memory;
	int stream_width;
};
typedef struct Cd Cd;



int Cd_init(
	Cd *s,		// pointer to state struct we will initialize
	sqlite3 *db,		// pointer to sqlite 3 database
	size_t data_size, 	// size of data block allocated on both
					//   the cpu and gpu
	size_t results_size,	// size of results block allocated on both
					//   the cpu and gpu
	int pinned_memory);

int Cd_cleanup(Cd *s);

int Cd_prepare_data(Cd *s, const char* sql_stmt);

int Cd_transfer_data(Cd *s);

int Cd_transfer_results(Cd *s);

int Cd_select(Cd *s, const char* sql_stmt);

int Cd_vm(Cd *s);



int Cd_test_queries(Cd *s);

int Cd_test_sizes(Cd *s, int streaming, int include_transfer);

int Cd_test_case(
	Cd *s,
	const char *sql,
	double *time_native,
	double *time_gpu,
	double *time_transfer,
	int *rows,

	int include_transfer);

int test_callback(void *rows, int argc, char **argv, char **azColName);





struct timeval Cd_starttime;
struct timeval Cd_endtime;

void Cd_timer_start();
double Cd_timer_stop();
double Cd_timer_end(const char* label);
void Cd_print_results(Cd *s, int n);
cudaError_t Cd_print_error();

#ifdef Cd_DEBUG
//const char *sqlite3OpcodeName(int i);
#endif


#define Cd_ROUNDTOPWR2(x)	\
x--;						\
x |= x >> 1;				\
x |= x >> 2;				\
x |= x >> 4;				\
x |= x >> 8;				\
x |= x >> 16;				\
x++;

#define Cd_MIN(a, b) a = ((a <= b) ? a : b);

#define Cd_MAX(a, b) a = ((a >= b) ? a : b);



