#include "cdb.h"

#define DATA_SIZE (Cd_MB * 128)
#define RESULTS_SIZE (Cd_MB * 128)

void printhelp(char **argv);

const char *Cd_test_cases[] = {
	"SELECT * FROM test WHERE column1>10",
};



int main(int argc, char **argv)
{
	sqlite3 *db;
	Cd sphy;
	int i, r;
	int dbarg = -1;
	int loadmemory = 0;
	int pinned_memory = 0;

	for(i = 1; i < argc; i++) {
		if(argv[i][0] == '-')
			switch(argv[i][1]) {
				case 'd' :
					dbarg = i + 1;
					printf("Using database %s\n", argv[i+1]);
					break;
				case 'm' :
					loadmemory = 1;
					printf("Loading database into memory\n");
					break;
				case 'p' :
					pinned_memory = 1;
					printf("Using pinned memory %i\n",pinned_memory);
					break;
				default :
					printhelp(argv);
			}
	}

	if(dbarg == -1) {
		printhelp(argv);
		exit(1);
	}

	if(loadmemory) {
		sqlite3_open(":memory:", &db);
		char sql[256];
		sprintf(sql, "ATTACH DATABASE '%s' AS loadfrom", argv[dbarg]);

		r = sqlite3_exec(db, sql, NULL, NULL, NULL);

		sqlite3_exec(db, "CREATE TABLE 'test' AS SELECT * FROM loadfrom.test", NULL, NULL, NULL);
		sqlite3_exec(db, "DETACH loadfrom", NULL, NULL, NULL);
	}

	if(pinned_memory) {
		r = sqlite3_open(argv[dbarg], &db);

	}

	if(r) {
		fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
                sqlite3_close(db);
                exit(1);
	}

	Cd_init(&sphy, db, DATA_SIZE, RESULTS_SIZE, pinned_memory);


#ifndef RUNTEST
	Cd_timer_start();
	Cd_prepare_data(&sphy, "SELECT * FROM test");
	const char* sql = "SELECT rowNo, column1 FROM test WHERE column1 < 90";
	char* err;

	Cd_timer_start();
	r = sqlite3_exec(db, sql, NULL, NULL, &err);
	double native = Cd_timer_end("native execution");

	if(err != NULL) {
		fprintf(stderr, "exec error: %s\n", err);
		exit(1);
	}

	Cd_timer_start();
	Cd_transfer_data(&sphy);
	Cd_select(&sphy, sql, 0);
	double vm = Cd_timer_end("vm execution");

	Cd_timer_start();
	Cd_transfer_results(&sphy);
	double results = Cd_timer_end("transfer results");

	printf("stream\n");
	printf("speedup:		%fx\n", native / vm);
	printf("speedup with results:	%fx\n", native / (vm + results)); 

	Cd_print_results(&sphy, 40);
#else
	Cd_test_queries(&sphy);

#endif

	Cd_cleanup(&sphy);
	sqlite3_close(db);

	return 0;
}

void printhelp(char** argv)
{
	printf("%s [options] -d <database file>\n", argv[0]);
	printf("  -m	Explicitly load database into memory for sqlite queries\n");
	printf("  -p	Use pinned memory for the data and results blocks\n");
	printf("  -d	Use this database file\n");
}

int Cd_test_queries(Cd *s)
{
	int i, r, rows;
	double time_native, time_gpu, time_transfer; 
	double speedup, sum_speedup = 0;
	double tspeedup, sum_tspeedup = 0;

	r = Cd_prepare_data(s, "SELECT * FROM test");

	if(r != Cd_SUCCESS) {
		fprintf(stderr, "Test failed to prepare data\n");
		return r;
	}

	r = Cd_transfer_data(s);

	if(r != Cd_SUCCESS) {
		fprintf(stderr, "Test failed to transfer data\n");
		return r;
	}
	
	i=0;
	 r = Cd_test_case(s,Cd_test_cases[i],&time_native, &time_gpu, &time_transfer, &rows, 0);
 
                speedup = time_native / time_gpu;
                sum_speedup += speedup;

                tspeedup = time_native / (time_gpu + time_transfer);
                sum_tspeedup += tspeedup;
	
	printf("\nspeedup (x)\ttspeedup (x)\tcpu (s)   \tgpu (s)   \ttrans (s) \trows\n");

	printf("%f\t%f\t%f\t%f\t%f\t%i\n",
                        speedup, tspeedup, time_native, time_gpu, time_transfer, rows);

	return Cd_SUCCESS;
}
int Cd_test_case(Cd *s, const char *sql,
	double *time_native, double *time_gpu, double *time_transfer, int *rows_, int include_transfer)
{
	int rows = 0;
	char *err;
	int r;


	Cd_timer_start();
	r = sqlite3_exec(s->db, sql, &test_callback, &rows, &err);
	time_native[0] = Cd_timer_stop();

	if(r != SQLITE_OK) {
                fprintf(stderr, "SQL error: %s\n%s\n", err, sql);
                sqlite3_free(err);
		return 1;
        }

	Cd_timer_start();
	if(include_transfer == 1)
		Cd_transfer_data(s);
	r = Cd_select(s, sql);
	time_gpu[0] = Cd_timer_stop();

	if(r != Cd_SUCCESS) {
		fprintf(stderr, "Cd error: case failed\n%s\n", sql);
		return 1;
	}

	Cd_timer_start();
	Cd_transfer_results(s);
	time_transfer[0] = Cd_timer_stop();

rows_[0] = rows;

	return Cd_SUCCESS;
}

int test_callback(void *rows,
	int argc __attribute__((unused)),
	char **argv __attribute__((unused)),
	char **azColName __attribute__((unused)))
{
	((int*)rows)[0]++;
	return 0;
}

