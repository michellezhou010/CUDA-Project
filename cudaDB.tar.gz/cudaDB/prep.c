#include "cdb.h"


void Cd_timer_start()
{
        gettimeofday(&Cd_starttime, NULL);
}

double Cd_timer_stop()
{
        gettimeofday(&Cd_endtime, NULL);
        double start = Cd_starttime.tv_sec +
                (double)Cd_starttime.tv_usec * .000001;
        double end = Cd_endtime.tv_sec +
                (double)Cd_endtime.tv_usec * .000001;
        return (end - start);
}

double Cd_timer_end(const char* label)
{
        double time = Cd_timer_stop();
        printf("%s time: %f seconds\n", label, time);
        return time;
}

cudaError_t Cd_print_error()
{
        cudaError_t r = cudaGetLastError();

        if(r != cudaSuccess)
                fprintf(stderr, "cuda error: %s\n",
                        cudaGetErrorString(r));

        return r;
}


int Cd_init(Cd *s, sqlite3 *db, size_t data_size, size_t results_size, int pinned_memory)
{
        
        s->db           = db;
        s->data_size    = data_size;
        s->results_size = results_size;
        s->pinned_memory = pinned_memory;

        cudaError_t r;
        int device;
        r = cudaGetDevice(&device);

        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                return Cd_ERR_DEVICE;
}

        struct cudaDeviceProp prop;
        r = cudaGetDeviceProperties(&prop, device);

        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                return Cd_ERR_DEVICE;
        }

        s->threads_per_block = Cd_THREADSPERBLOCK;
        s->stream_width = Cd_STREAMWIDTH;

#ifdef Cd_DEBUG
        printf("==================================================\n");
        printf(" My Device information \n");
        printf(" Device name:                   %s\n", prop.name);
        printf(" multiProcessorCount:   %i\n", prop.multiProcessorCount);
        printf(" kernelExecTimeoutEnabl:%i\n", prop.kernelExecTimeoutEnabled);
        printf(" integrated:            %i\n", prop.integrated);
        printf(" canMapHostMemory:      %i\n", prop.canMapHostMemory);
        printf(" totalGlobalMem:        %u (%.2fGB)\n", (unsigned)prop.totalGlobalMem,
                (double)prop.totalGlobalMem / 1073741824.0);

        printf(" totalConstMem:         %u (%.2fKB)\n", (unsigned)prop.totalConstMem,
                (double)prop.totalConstMem / 1024.0);
        printf(" maxThreadsPerBlock:    %i\n", prop.maxThreadsPerBlock);
        printf(" maxThreadsDim:         %i %i %i\n", prop.maxThreadsDim[0],
                prop.maxThreadsDim[1], prop.maxThreadsDim[2]);
        printf(" maxGridSize:           %i %i %i\n", prop.maxGridSize[0],
                prop.maxGridSize[1], prop.maxGridSize[2]);
        printf(" sharedMemPerBlock:     %u (%.2fKB)\n", (unsigned)prop.sharedMemPerBlock,
                (double)prop.sharedMemPerBlock / 1024.0);
        printf(" regsPerBlock:          %i\n", prop.regsPerBlock);
        printf(" warpSize:              %i\n", prop.warpSize);
        printf("==================================================\n");
#endif

        if(pinned_memory) {
                r = cudaMallocHost((void**)&s->data_cpu, data_size + sizeof(Cd_data));
                printf("OK!");
                if(r != cudaSuccess) {
                        fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_MEM;
                }
     r = cudaMallocHost((void**)&s->results_cpu, results_size + sizeof(Cd_results));
                if(r != cudaSuccess) {
                        fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_MEM;
                }

                if((r = cudaMallocHost((void*)&s->stmt_cpu, sizeof(Cd_stmt))) != cudaSuccess) {
                        fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_MEM;
                }
        }
        else {

                s->data_cpu = malloc(data_size + sizeof(Cd_data));
                s->results_cpu = malloc(results_size + sizeof(Cd_results));
                s->stmt_cpu = malloc(sizeof(Cd_stmt));
                if(s->data_cpu == NULL || s->results_cpu == NULL ||
                        s->stmt_cpu == NULL) {
                        fprintf(stderr, "Mallocs failed");
                        return Cd_ERR_MEM;
                }
        }


        r = cudaMalloc((void**)&s->data_gpu, data_size);
        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAMALLOC;
        }

        r = cudaMalloc((void**)&s->results_gpu, results_size + sizeof(Cd_results));
        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAMALLOC;
        }

        return Cd_SUCCESS;
}


int Cd_prepare_data(Cd *s, const char* sql_stmt)
{
        sqlite3_stmt *stmt;
        Cd_data *data = s->data_cpu;

        int i;
        for(i = 0; sql_stmt[i] != '\0'; i++);
        int q;
        q = sqlite3_prepare_v2(s->db,sql_stmt, i, &stmt,NULL);
        if (q!=SQLITE_OK){
                printf("return %i , massg: %s \n",q,sqlite3_errmsg(s->db));         
}


#ifdef Cd_DEBUG
        Cd_timer_start();
#endif

       int r = sqlite3_step(stmt);

        int columns = sqlite3_column_count(stmt);
        if(r != SQLITE_ROW && r != SQLITE_DONE)
                {
                fprintf(stderr, "failed to return row.\n");

                return Cd_ERR_STMT;
}

        data->columns = columns;
        int offset = 0;
        for(i = 0; i < columns; i++) {

                if(sqlite3_column_type(stmt, i)== SQLITE_INTEGER){
#ifdef USE_INT64
                         data->types[i] = Cd_INT64;
                        data->offsets[i] = offset;
                        offset += sizeof(i64);
#else
                        data->types[i] = Cd_INT;
                        data->offsets[i] = offset;
                        offset += sizeof(int);
#endif
                }
                else if (sqlite3_column_type(stmt, i) == SQLITE_FLOAT){
#ifdef USE_DOUBLES
                      
                        data->types[i] = Cd_DOUBLE;
                        data->offsets[i] = offset;
                        offset += sizeof(double);
#else
                        data->types[i] = Cd_FLOAT;
                        data->offsets[i] = offset;
                        offset += sizeof(float);
#endif
                }
                else{
                        fprintf(stderr,
                                "Error: the data type for column %i is not supported\n",
                                i);
                        return Cd_ERR_TYPE;
                        }

        }

        int stride = offset;


  stride--;
        stride |= stride >> 1;
        stride |= stride >> 2;
        stride |= stride >> 4;
        stride |= stride >> 8;
        stride |= stride >> 16;
        stride++;
  s->data_cpu->stride = stride;
        int rows = 0;
        int last_row = floor((float)s->data_size / (float)stride);
        char *d = (char*)&s->data_cpu->d;
        void *p;

        do {
                for(i = 0; i < columns; i++) {
                        p = d + rows * stride + data->offsets[i];

                        switch(data->types[i]) {

                                case Cd_INT :
                                        ((int*)p)[0] = sqlite3_column_int(stmt, i);
                                        break;

                                case Cd_INT64 :
                                        ((i64*)p)[0] = sqlite3_column_int64(stmt, i);
                                        break;

                                case Cd_FLOAT :
                                        ((float*)p)[0] = (float)sqlite3_column_double(stmt, i);
                                        break;

                                case Cd_DOUBLE :
                                        ((double*)p)[0] = sqlite3_column_double(stmt, i);
                                        break;

                                default:
                                        fprintf(stderr,
                                                "Error: the data type for column %i is not supported\n",
                                                i);
                                        return Cd_ERR_TYPE;
                        }
                }

                rows++;
	 if(rows >= last_row) {
                        fprintf(stderr, "Warning: selected data too large for gpu data block\n");
                        break;
                }
        } while(sqlite3_step(stmt) == SQLITE_ROW);

#ifdef COLUMNROW
        char *temp = (char*)malloc(s->data_size);
        int offsets[columns];
        int j;

        for(i = 0; i < rows; i++) {
                for(j = 0; j < columns; j++) {
                        switch(data->types[j]) {

                                case Cd_INT :
                                        ((int*)(temp + data->offsets[j] * rows))[i] =
                                                ((int*)(d + i * stride + data->offsets[j]))[0];
                                        break;

                                case Cd_INT64 :
                                        ((i64*)(temp + data->offsets[j] * rows))[i] =
                                                ((i64*)(d + i * stride + data->offsets[j]))[0];
                                        break;

                                case Cd_FLOAT :
                                        ((float*)(d + data->offsets[j] * rows))[i] =
                                                ((float*)(d + i * stride + data->offsets[j]))[0];
                                        break;

                                case Cd_DOUBLE :
                                        ((double*)(temp + data->offsets[j] * rows))[i] =
                                                ((double*)(d + i * stride + data->offsets[j]))[0];
                                        break;
                        }
                }
        }

        for(i = 0; i < columns; i++)
                data->offsets[i] *= rows;

  memcpy(d, temp, s->data_size);
        free(temp);
#endif

        data->rows = rows;


#ifdef Cd_DEBUG
        Cd_timer_end("SQLite select");
#endif
        sqlite3_finalize(stmt);

        return Cd_SUCCESS;
}




int Cd_transfer_data(Cd *s)
{
    int r;
#ifdef Cd_DEBUG
        Cd_timer_start();
#endif

    r = cudaMemcpy(s->data_gpu, s->data_cpu->d,
                s->data_cpu->rows * s->data_cpu->stride,
                cudaMemcpyHostToDevice);
#ifdef Cd_DEBUG
        Cd_timer_end("cudaMemcpy");
#endif


        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAMEMCPY;
        }

        return Cd_SUCCESS;
}


int Cd_transfer_results(Cd *s)
{
        cudaError_t r;

        r = cudaMemcpy(s->results_cpu, s->results_gpu,
                sizeof(Cd_results), cudaMemcpyDeviceToHost);

        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error through transfering: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAMEMCPY;
        }

        r = cudaMemcpy(s->results_cpu,
                s->results_gpu,
                s->results_cpu->rows * s->results_cpu->stride + sizeof(Cd_results),
                cudaMemcpyDeviceToHost);

        if(r != cudaSuccess) {
                fprintf(stderr, "Cuda error when trans row: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAMEMCPY;
        }

        return Cd_SUCCESS;
}



