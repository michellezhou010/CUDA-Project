#include "cdb.h"
const char *sqlite3OpcodeName[] = { "?",
"MemLoad",
"Column",
"SetCookie",
"IfMemPos",
"Sequence",
"MoveGt",
"RowKey",
"OpenWrite",
"If",
"Pop",
"CollSeq",
"OpenRead",
"Expire",
"AutoCommit",
"IntegrityCk",
"Not",
"Sort",
"Function",
"Noop",
"Return",
"NewRowid",
"IfMemNeg",
"Variable",
"String",
"RealAffinity",
"ParseSchema",
"Close",
"CreateIndex",
"IsUnique",
"IdxIsNull",
"NotFound",
"Int64",
"MustBeInt",
"Halt",
"Rowid",
"IdxLT",
"AddImm",
"Statement",
"RowData",
"MemMax",
"Push",
"NotExists",
"MemIncr",
"Gosub",
"Integer",
"MemInt",
"Prev",
"CreateTable",
"Last",
"IdxRowid",
"MakeIdxRec",
"ResetCount",
"FifoWrite",
"Callback",
"ContextPush",
"DropTrigger",
"DropIndex",
"IdxGE",
"Or",
"And",
"IdxDelete",
"Vacuum",
"MoveLe",
"IsNull",
"NotNull",
"Ne",
"Eq",
"Gt",
"Le",
"Lt",
"Ge",
"IfNot",
"BitAnd",
"BitOr",
"ShiftLeft",
"ShiftRight",
"Add",
"Subtract",
"Multiply",
"Divide",
"Remainder",
"Concat",
"Negative",
"DropTable",
"BitNot",
"String8",
"MakeRecord",
"Delete",
"AggFinal",
"Dup",
"Goto",
"TableLock",
"FifoRead",
"Clear",
"IdxGT",
"MoveLt",
"VerifyCookie",
"AggStep",
"Pull",
"SetNumColumns",
"AbsValue",
"Transaction",
"ContextPop",
"Next",
"IdxInsert",
"Distinct",
"Insert",
"Destroy",
"ReadCookie",
"ForceInt",
"LoadAnalysis",
"OpenVirtual",
"Explain",
"IfMemZero",
"OpenPseudo",
"Null",
"Blob",
"MemStore",
"Rewind",
"MoveGe",
"MemMove",
"MemNull",
"Found",
"Real",
"HexBlob",
"NullRow",
"NotUsed_127",
"NotUsed_128",
"NotUsed_129",
"NotUsed_130",
"NotUsed_131",
"NotUsed_132",
"NotUsed_133",
"NotUsed_134",
"NotUsed_135",
"NotUsed_136",
"ToText",
"ToBlob",
"ToNumeric",
"ToInt",
"ToReal",
};


int Cd_select(Cd *s, const char* sql_stmt)
{
        sqlite3_stmt *stmt;
        int i;
        for(i = 0; sql_stmt[i] != '\0'; i++);
        sqlite3_prepare_v2(s->db, sql_stmt, i, &stmt, NULL);
	Vdbe *vdbe = (Vdbe*) stmt;
        VdbeOp *o = vdbe->aOp;

#ifdef Cd_DEBUG
	 printf("%s:%s\t%s\t%s\t%s\n","No","Opcode",
                        "P1","P2","P3");

	for(i = 0; i < vdbe->nOp; i++)
		printf("%i:  %i \t%i\t%i\t%i\n",i,o[i].opcode,
			o[i].p1,o[i].p2,o[i].p3);
#endif

    for(i = 0; i < vdbe->nOp && o[i].opcode != OP_Next; i++);
	int start = o[i].p2;
    Cd_op *op;
    s->stmt_cpu->nOp = vdbe->nOp;
	s->stmt_cpu->start = start;
    char *agg_name;
    for(i = 0; i < vdbe->nOp; i++) {
		op = &(s->stmt_cpu->op[i]);
		op->opcode = o[i].opcode;
		op->p1 = o[i].p1;
		op->p2 = o[i].p2;
		op->p3 = o[i].p3;
		op->p5 = o[i].p5;

		switch(op->opcode) {
			case OP_Int64 :
				 
				
				op->p4.li = o[i].p4.pI64[0];
				break;

			case OP_Real :


				op->p4.d = o[i].p4.pReal[0];
				break;

			case OP_AggStep :
			case OP_AggFinal :
				agg_name = o[i].p4.pFunc->zName;

				if(strcmp(agg_name, Cd_AGG_STR_COUNT) == 0) {
					op->p4.i = Cd_AGG_COUNT;
				}
				else if(strcmp(agg_name, Cd_AGG_STR_MAX) == 0) {
					op->p4.i = Cd_AGG_MAX;
				}
				else if(strcmp(agg_name, Cd_AGG_STR_MIN) == 0) {
					op->p4.i = Cd_AGG_MIN;
				}
				else if(strcmp(agg_name, Cd_AGG_STR_SUM) == 0) {
					op->p4.i = Cd_AGG_SUM;
				}
				else if(strcmp(agg_name, Cd_AGG_STR_AVG) == 0) {
					op->p4.i = Cd_AGG_AVG;
				}
				break;
		}
	}

	sqlite3_finalize(stmt);

		Cd_vm(s);

	return Cd_SUCCESS;
}

int Cd_cleanup(Cd *s)
{
        cudaError_t r;

        if(s->pinned_memory) {
                if((r = cudaFreeHost(s->data_cpu)) != cudaSuccess) {
                        fprintf(stderr, "Cuda error data cpu: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_CUDAFREEHOST;
                }

                if((r = cudaFreeHost(s->results_cpu)) != cudaSuccess) {
                        fprintf(stderr, "Cuda error result cpu: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_CUDAFREEHOST;
                }

                if((r = cudaFreeHost(s->stmt_cpu)) != cudaSuccess) {
                        fprintf(stderr, "Cuda error statement cpu: %s\n", cudaGetErrorString(r));
                        return Cd_ERR_CUDAFREEHOST;
                }
        }
        else {
                free(s->data_cpu);
                free(s->results_cpu);
                free(s->stmt_cpu);

        }

        if((r = cudaFree((void*)s->data_gpu)) != cudaSuccess) {
                fprintf(stderr, "Cuda error free gpu data: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAFREE;
        }



        if((r = cudaFree((void*)s->results_gpu)) != cudaSuccess) {

                fprintf(stderr, "Cuda error when free result: %s\n", cudaGetErrorString(r));
                return Cd_ERR_CUDAFREE;
        }
                return Cd_SUCCESS;
}
              
