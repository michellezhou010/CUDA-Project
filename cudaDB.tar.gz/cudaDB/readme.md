First of all, User should generate the dataset for the database:

for example, I generate 10000 recoords in my cudadb.db(included in cudaDB);
for generating the records:
gcc -O2 -Wall -Wextra -o db db.c -lsqlite3
        ./db cudadb.db 10000

here, cudadb.db is the name of the database you just want to create,
the number here is how many records you want to input in your database.

Then,
we need to test our query execution by following steps of the makefile.

there are different choices users can select:
  -m	load database into memory for sqlite queries
  -p    Use pinned memory for the data and results blocks
  -d    Use this database file directly
when running the program, you should also follow the instruction as below:

 [-m/-p/-d] -d <db file you created>

For instance,
I do      ./debug/cdb -p -d cudadb.db         
